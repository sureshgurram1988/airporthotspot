export default function Header() {
  return (
    <header className="topbar">
      <div className="brand-mark">A</div>
      <div>
        <strong>Airport Carbon Hotspot Finder</strong>
        <span>Operational emissions POC</span>
      </div>
    </header>
  );
}
